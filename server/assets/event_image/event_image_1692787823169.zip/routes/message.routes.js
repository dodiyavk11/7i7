const { messageSend, fetchMessageByOrderId } = require("../controllers/message.controller");
const { Imgupload } = require("../middleware/ChatMiddle");
const { checkAuth } = require("../middleware/checkAuthMiddle")

module.exports = (app) => {
  app.post("/message/send/:order_id", [checkAuth,Imgupload.array("files[]",999999)], messageSend);
  app.post("/message/get/:order_id", [checkAuth], fetchMessageByOrderId)
}