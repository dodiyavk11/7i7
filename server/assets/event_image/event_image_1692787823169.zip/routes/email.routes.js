const { EmailTemplate, FatchEmailTemplate, AddContent } = require("../controllers/email.controller")
const { checkAuth, isAdmin } = require("../middleware/checkAuthMiddle")


module.exports = (app) =>{
    app.post("/email/template",[checkAuth,isAdmin],EmailTemplate);
    app.post("/fatch/template/:id",[checkAuth,isAdmin],FatchEmailTemplate)
    app.patch("/send/text/:id",[checkAuth,isAdmin],AddContent)
}