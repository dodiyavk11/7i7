
const Models = require("../models")
const { sendVerifyMail, emailTemplate } = require("../utils/emailsUtils")

exports.messageSend = async (req, res) => {
  try {
    const uId = req.userId
    const { order_id } = req.params
    const { message } = req.body
    const { files } = req.body

    // return res.status(500).send({ status: false, message: "please send message", data: [] });

    const getUserInfo = await Models.Users.findOne({ where: { id: uId } });
    let chatData = { user_id: uId, order_id, role: getUserInfo.dataValues.role }

    if (message || message !== "") { chatData.message = message }

    // image add
    if (files || files !== "") {
      const image = req.files;
      if (image) {
        const array = await Promise.all(image.map(async (val) => {
          return val.filename
        }))
        let string = array.join(',')
        chatData.files = string
      }
    }

    await Models.Order_Comment.create(chatData)

    // change update status in order api, so that user and admin gets a red exclamation mark
    getUserInfo.dataValues.role !== 0 && await Models.Orders.update({ update_status: 2 }, { where: { id: order_id } })
    getUserInfo.dataValues.role === 0 && await Models.Orders.update({ update_status_admin: 2 }, { where: { id: order_id } })
    // await Models.Orders.update({ update_chat_status_admin: 2 }, { where: { id: order_id } })


    const ordername = await Models.Orders.findOne({ where: { id: order_id } })
    const user = await Models.Users.findOne({where:{id:ordername.dataValues.uId}})
    const admin = await Models.Users.findAll({where:{role:1}})
    
    
    // content = `hello from 7i7 you  have chat notification of order ${ordername.dataValues.ordername} `

    const mailTexts = await Models.email_template.findOne({where:{email_type:'chat_message'}})
    let text = mailTexts.email_content 
    let subject = mailTexts.header
    
    if (getUserInfo.dataValues.role === 0) {

      
      const adminUsers = await Models.Users.findAll({ where: { role: 1 } });
      // regular user sent a message, send email notification to all admins
      adminUsers.map( async (val) => {
        text = text.replace("{company_name}", val.company);
        const mail = await emailTemplate(text)
        sendVerifyMail(val.email, subject,"" ,mail);
      });
    } else {
      // const users = await Models.Orders.findOne({ where: { id: order_id } })
      // const user = await Models.Users.findOne({ where: { id: users.dataValues.uId } })
    //   admin.map(async(val)=>{
    //   const adminUsers = await Models.Users.findOne({ where: { email: val.email } });
    // })
    const admin = await Models.Users.findOne({where:{id:uId}})
    text = text.replace("{company_name}", admin.dataValues.company);
    const mail = await emailTemplate(text)
      sendVerifyMail(user.dataValues.email, subject, "",mail);
    }
 res.status(200).send({ status: true, message: "Nachricht erfolgreich gesendet", data:[]})
          
  } catch (err) {
    console.log(err)
    res.status(500).send({ status: false, message: "Nachricht kann nicht gesendet werden, da ist ein Fehler aufgetreten", data: [] ,error: err.message })
  }
}

exports.fetchMessageByOrderId = async (req, res) => {
  try {
    const { order_id } = req.params

    const getMessages = await Models.Order_Comment.findAll({ where: { order_id } })


    // modify data from each array
    const getInfo = await getMessages.map((val) => {
      delete val.dataValues.order_id
      return val.dataValues.user_id
    })

    // get user img comment wise
    const getUserImg = await Promise.all(getInfo.map(async (val) => {
      const getUserInfo = await Models.Users.findOne({ where: { id: val } ,  paranoid: false})
      return getUserInfo.dataValues.userImg
    }))

    // get user name
    const getUsername = await Promise.all(getInfo.map(async (val) => {
      const getUserInfo = await Models.Users.findOne({ where: { id: val } ,  paranoid: false})
      return getUserInfo.dataValues.fname + " " +getUserInfo.dataValues.lname
    }))


    // adding image to main object
    getUserImg.map((val, i) => getMessages[i].dataValues.userImg = val)
    getUsername.map((val, i) => getMessages[i].dataValues.name = val)
    res.status(200).send({ status: true, message: "Nachricht erfolgreich erhälten", data: getMessages })

  } catch (err) {
    console.log(err)
    res.status(500).send({ status: false, message: "Ich kann keine Nachrichten empfängen, da ist ein Fehler aufgetreten", data: [],error: err.message })
  }
}